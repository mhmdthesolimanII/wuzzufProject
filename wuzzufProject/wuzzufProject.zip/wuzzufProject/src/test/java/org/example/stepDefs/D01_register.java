package org.example.stepDefs;
import com.github.javafaker.Faker;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.eo.Se;
import io.cucumber.messages.types.Hook;
import org.example.pages.P01_register;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;

import java.util.concurrent.TimeUnit;

public class D01_register {
P01_register register = new P01_register();
SoftAssert soft = new SoftAssert();
    Faker fake = new Faker();
        WebDriver driver;
        @Given("the user is on the registration page and enters valid registration details")
        public void theUserIsOnTheRegistrationPageAndEntersValidRegistrationDetails() throws InterruptedException {
        Thread.sleep(1500);
        register.joinNowButton.click();
        String fakeUserName = fake.name().username();
        register.firstname.sendKeys(fakeUserName);
        String fakeLastName = fake.name().lastName();
        register.lastName.sendKeys(fakeLastName);
        String fakeEmail = fake.internet().emailAddress();
        register.email.sendKeys(fakeEmail);
        String fakePassword = fake.internet().password();
        register.password.sendKeys(fakePassword);
        Thread.sleep(500);
        register.jobLookingFor.sendKeys("QA software engineer");
        register.signupButton.click();
        Thread.sleep(3000);
        register.student.click();
        Thread.sleep(1500);
        register.fullTime.click();
        Thread.sleep(2000);
        register.itSoftwareDevelopment.click();
        Thread.sleep(500);
        register.expectedSalary.sendKeys("30000");
        Thread.sleep(1500);
        register.saveAndContinue.click();
        Thread.sleep(1500);
        new Actions(Hooks.driver).click(register.day).sendKeys("15").sendKeys(Keys.ENTER).perform();
        Thread.sleep(1500);
        new Actions(Hooks.driver).click(register.month).sendKeys("April").sendKeys(Keys.ENTER).perform();
        Thread.sleep(1500);
        new Actions(Hooks.driver).click(register.year).sendKeys("1996").sendKeys(Keys.ENTER).perform();
        Thread.sleep(1500);
        register.male.click();
        Thread.sleep(1500);
        new Actions(Hooks.driver).click(register.nationality).sendKeys("Egypt").sendKeys(Keys.ENTER).perform();
        Thread.sleep(1500);
        new Actions(Hooks.driver).click(register.city).sendKeys("Cairo").sendKeys(Keys.ENTER).perform();
        Thread.sleep(1500);
        new Actions(Hooks.driver).click(register.area).sendKeys("Mokattam").sendKeys(Keys.ENTER).perform();
        driver.findElement(By.cssSelector("input[type=\"tel\"]")).sendKeys("01022009185");
        Thread.sleep(5000);
        register.saveAndContinue2.click();
    }
}
