package org.example.pages;

import org.example.stepDefs.Hooks;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.lang.ref.WeakReference;

public class P01_register {
    public P01_register(){
        PageFactory.initElements(Hooks.driver,this);
    }
    @FindBy(css = "div[class=\"navbar-form navbar-right signin-register-btns hidden-xs\"] a[href=\"https://wuzzuf.net/register\"]")
    public WebElement joinNowButton;
    @FindBy(id = "firstname")
    public WebElement firstname;
    @FindBy(id = "lastname")
    public WebElement lastName;
    @FindBy(id = "email")
    public WebElement email;
    @FindBy(css = "div[class=\"css-150a24d\"] input[type=\"password\"]")
    public WebElement password;
    @FindBy(css = "input[placeholder=\"e.g. Android Developer\"]")
    public WebElement jobLookingFor;
    @FindBy(css = "button[class=\"css-6lejne ezfki8j0\"]")
    public WebElement signupButton;
    @FindBy(css = "div[name=\"careerLevel\"] div:nth-child(1)")
    public WebElement student;
    @FindBy(css = "button[id=\"1\"]")
    public WebElement fullTime;
    @FindBy(css = "div[class=\"css-1sdnanw ediq4wm2\"] div:nth-child(1)")
    public WebElement itSoftwareDevelopment;
    @FindBy(css = "input[name=\"minimumSalary\"]")
    public WebElement expectedSalary;
    @FindBy(css = "div[class=\"css-nwhan4\"] button")
    public WebElement saveAndContinue;
    @FindBy(css = "div[class=\"css-1x21pox e6pv2vl4\"] div[class=\"row\"] div[class=\"col-2-lg col-12\"] div[class=\" css-1dgicot-container\"] div[class=\" css-1hwfws3\"]")
    public WebElement day;
    @FindBy(css = "div[class=\"css-1x21pox e6pv2vl4\"] div:nth-child(2) div[class=\" css-1dgicot-container\"] div[class=\" css-1hwfws3\"]")
    public WebElement month;
    @FindBy(css = "div[class=\"css-1x21pox e6pv2vl4\"] div:nth-child(3) div[class=\" css-1hwfws3\"]")
    public WebElement year;
    @FindBy(css = "div[class=\"css-18uqayh\"] div[class=\"css-3pwpkg\"] label:nth-child(1)")
    public WebElement male;
    @FindBy(css = "form[novalidate] div:nth-child(6) div[class=\" css-zh6qap-control\"] div[class=\" css-1hwfws3\"]")
    public WebElement nationality;
    @FindBy(css = "#basic-info-form > div:nth-child(2) > div:nth-child(3) > div > div.css-1dgicot-container > div > div.css-1hwfws3")
    public WebElement city;
    @FindBy(css = "#basic-info-form > div:nth-child(2) > div:nth-child(4) > div > div.css-1dgicot-container > div > div.css-1hwfws3")
    public WebElement area;
    @FindBy(css = "#basic-info-form > div:nth-child(3) > div > div > div.css-150a24d > input")
    public WebElement phoneNumber;
    @FindBy(css = "div[class=\"css-nwhan4\"] button[class=\"css-1wj05oe ezfki8j0\"]")
    public WebElement saveAndContinue2;



}

